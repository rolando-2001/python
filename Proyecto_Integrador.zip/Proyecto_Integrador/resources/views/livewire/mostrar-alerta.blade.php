<div class="border border-red-500  bg-red-100 text-red-700 font-bold uppercase p-2 mt-2 text-xs ">
   {{$message}}
</div>
